package cookBook;
import java.util.ArrayList;


public class plan {

public static final String ERR_01 = "Please fill in blank boxes ";  // make a delete box button / check array lenght vs all other arrays 
public static final String ERR_02 = "Number need to be more then 0"; // 0 is ok 
public static final String GOOD = "Looking good";

public static boolean check1 (ArrayList<String> name, ArrayList<Double> value, ArrayList<Integer> type) {
	 return (name.size() == value.size() && value.size() == type.size());
}

public static boolean check2(ArrayList<Double> value) {
	
    for (Double val : value) {
        if (val <= 0) {
            return false; 
        }	}   
    
    																																		
    return true; 
}

public static void main(String[] args) {  // all the add stuff is just for error checking 
		
		ArrayList<String> name = new ArrayList<String> ( );
		
		name.add("Flour");  //=2
		name.add("Sugar"); //=3
		name.add("Eggs"); //=5
		name.add("Milk"); //=1
		name.add("Vanilla"); // teaspoons and tablespoons dont need converting so make value == 0
		ArrayList<Double> value = new ArrayList<Double> ( );
		
		value.add((double) 150);
        value.add((double)75);
		value.add((double) 2);
		value.add((double) 70);
		value.add((double)2); //---> Figure out how to deal with the teaspoon/tablespoon dilemma. ?? maybe make boolean ??
		
		ArrayList<Integer>type = new ArrayList<Integer> ( ); // assign value of  Ex: flour = 1, Suger = 2... From insta cart thing 
		
		type.add((int)2);
		type.add((int)3);
		type.add((int)5);
		type.add((int)1);
		type.add((int)0);
		
		boolean error = check1(name, value, type);
		boolean error2= check2(value);
		 
		   if (error && error2) {
			   
			   convert converter = new convert(value, type); 
	           converter.ConvertIngrediants();  
	           ArrayList<String> convertedIngredients = converter.Final;
	           ArrayList<String> convertedMeasurment = converter.FinalMeasurement;
	           
	           int i=0;
	           for ( String ingredient : convertedIngredients) {
	        	   System.out.println(name.get(i)+": "+ingredient + convertedMeasurment.get(i));
	               i++;
	           }
	           
	        } else {
	        	if (error==false && error2==true) {
	            System.out.println(ERR_01);
	        	}
	        	else {
	        	System.out.println(ERR_02);
	        	}
	        }
	    }
	}
