package cookBook;
import java.util.ArrayList;


	public class convert {
		
		private  ArrayList<Double> ingredients; 
		private  ArrayList<Integer> value; 
	    ArrayList<String> Final; 
	    ArrayList<String> FinalMeasurement;
	    
	public convert () {
		 Final = new ArrayList<>();
		 FinalMeasurement = new ArrayList<>();
	}
	
    public convert (ArrayList<Double> varray, ArrayList<Integer> tarray) {
		this.ingredients = varray;
		this.value = tarray;
		 Final = new ArrayList<>();
		 FinalMeasurement = new ArrayList<>();
	}
    
	public void ConvertIngrediants () { 	
		
		for (int i = 0; i < this.value.size(); i++) {
			
			if (this.value.get(i) == 0) {
				 String converted = Teaspoons(this.ingredients.get(i));
				Final.add(converted);
				FinalMeasurement.add(" Teaspoons/Tablespoons ");
			}     
			if (this.value.get(i) == 1) {
				 String converted = Milk(this.ingredients.get(i));
				Final.add(converted);
				FinalMeasurement.add(" Cups");
			}     
			if (this.value.get(i) == 2) {
				 String converted = Flour(this.ingredients.get(i));
				Final.add(converted);
				FinalMeasurement.add(" Cups");
			}     
			if (this.value.get(i) == 3) {
				 String converted = Suger(this.ingredients.get(i));
				Final.add(converted);
				FinalMeasurement.add(" Cups");
			} 
			if (this.value.get(i) == 4) {
				 String converted = Oil(this.ingredients.get(i));
				Final.add(converted);
				FinalMeasurement.add(" Cups");
			} 
			if (this.value.get(i) == 5) {
				 String converted = Eggs(this.ingredients.get(i));
				Final.add(converted);
				FinalMeasurement.add("");
			} 
				}     
					}	
	
	public String Teaspoons (double tea) {
			String con = stringCon (tea);
	
		return con;		}
	
	public String Milk(double milk) {
			double m = milk/246.05;
			String con = stringCon (m);
					
		return con;		}
	
	public String Flour (double flour) {
			double f = flour/125.39;
			String con = stringCon (f);
		
		return con;		}
	
	public String Suger (double suger) {
			double s = suger/165.61;
			String con = stringCon (s);
		
		return con;		}
	
	public String Oil (double oil) {
			double o = 208.2;
			String con = stringCon (o);
		
		return con;		}
	
	public String Eggs (double eggs) {	
			int e = (int) Math.round(eggs);
			String egg = Integer.toString(e) ;
		
		return egg;		}

	public String stringCon(double a) {
		int b = (int) Math.floor(a);
		double f = a - b;
    
		String m;
    
		if (f <= 0.125) {
			m = "0";
		} else if (f <= 0.25) {
			m = "1/8";
		} else if (f <= 0.33) {
			m = "1/3";
		} else if (f < 0.375) {
			m = "3/8";
		} else if (f < 0.5) {
			m = "1/2";
		} else if (f < 0.62) {
			m = "5/8";
		} else if (f < 0.67) {
			m = "2/3";
		} else if (f < 0.75) {
			m = "3/4";
		} else if (f < 0.87) {
			m = "7/8";
		} else {
			return Integer.toString(b + 1);
		}
    
		return (b == 0) ? ((m.equals("0")) ? "" : m) : ((m.equals("0")) ? String.valueOf(b) : b + " " + m);
	}
	 		}  
	
			
		
		
		
	
	
	