/**
 * 
 */
/**
 * 
 */
module cookBook {
}