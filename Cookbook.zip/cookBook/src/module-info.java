/**
 * 
 */
/**
 * 
 */
module cookBook {
	requires javafx.graphics;
}